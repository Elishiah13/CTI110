# Elishiah Reed
# P4LAB1
# 11/02/2025
# Using turtle to draw a square and a triangle

import turtle

wn = turtle.Screen()
wn.bgcolor("lightblue")

t = turtle.Turtle()
t.pensize(3)
t.color("darkblue")

for i in range(4):
    t.forward(100)
    t.right(90)

t.penup()
t.goto(-50, -50)
t.pendown()

sides = 0
while sides < 3:
    t.forward(100)
    t.left(120)
    sides += 1

wn.mainloop()