# Elishiah Reed
# P4LAB1
# 11/02/2025
# Using turtle to draw initials
import turtle

wn = turtle.Screen()
wn.bgcolor("white")

t = turtle.Turtle()
t.pensize(5)
t.color("blue")

t.penup()
t.goto(-150, 0)
t.pendown()

t.left(90)
t.forward(100)
t.right(90)

for i in range(3):
    t.forward(50)
    t.penup()
    t.backward(50)
    t.right(90)
    t.forward(50)
    t.left(90)
    t.pendown()

t.penup()
t.goto(50, 0)
t.setheading(90)
t.pendown()

t.forward(100)

t.right(90)
t.circle(-25, 180)

t.penup()
t.goto(50, 50)
t.setheading(-45)
t.pendown()

count = 0
while count < 1:
    t.forward(70)